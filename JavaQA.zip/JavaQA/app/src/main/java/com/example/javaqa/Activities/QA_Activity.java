package com.example.javaqa.Activities;

public class QA_Activity {
}
