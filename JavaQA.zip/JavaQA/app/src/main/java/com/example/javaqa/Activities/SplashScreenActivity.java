package com.example.javaqa.Activities;

public class SplashScreenActivity {
}
